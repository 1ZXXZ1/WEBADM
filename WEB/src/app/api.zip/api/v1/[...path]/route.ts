import { NextRequest, NextResponse } from 'next/server';

/**
 * Catch-all API proxy route — proxies all /api/v1/* requests to the Samba AD DC Management API backend.
 *
 * Configuration:
 *   SAMBA_API_URL — full base URL of the backend (default: http://127.0.0.1:8099/api/v1)
 *
 * Cache TTL: FULLY DISABLED — all responses are forced no-store at every level:
 *   - Route segment config: dynamic + fetchCache = 'force-no-store'
 *   - fetch() option: cache = 'no-store'
 *   - Response headers: Cache-Control, Pragma, Expires
 *   - next.config.ts headers() for API routes
 */

// ─── Route segment config: fully disable all Next.js caching ──────────────
export const dynamic = 'force-dynamic';
export const fetchCache = 'force-no-store';
export const revalidate = 0;

const BACKEND_URL = process.env.SAMBA_API_URL || 'http://127.0.0.1:8099/api/v1';
const MAX_BODY_SIZE = 10 * 1024 * 1024;

/**
 * FastAPI endpoints that REQUIRE a trailing slash.
 * Without the slash, FastAPI returns 307 redirect which can lose POST body
 * in some Node.js fetch implementations — causing "Not Found" / 404 errors.
 *
 * Source: openapi.json — all paths ending with '/'
 */
const TRAILING_SLASH_ENDPOINTS = new Set([
  'users',
  'groups',
  'computers',
  'contacts',
  'ous',
  'sites',
  'sites/subnets',
  'fsmo',
  'gpo',
  'service-accounts',
  'shell',
  'batch',
  'shell/projet',
  'ai/chat',
]);

async function proxyRequest(request: NextRequest, method: string) {
  try {
    // Build the target URL from the catch-all path segments
    // Preserve trailing slash — FastAPI requires it for certain endpoints
    const rawPath = request.nextUrl.pathname.replace(/^\/api\/v1\/?/, '');
    const hasTrailingSlash = rawPath.endsWith('/') && rawPath.length > 1;
    const pathSegments = rawPath.split('/').filter(Boolean);
    const joinedPath = pathSegments.join('/');

    let targetUrl = `${BACKEND_URL}/${joinedPath}`;

    // Auto-add trailing slash for known FastAPI endpoints that require it.
    // This avoids 307 redirects which can drop POST body in Node.js fetch.
    if (!hasTrailingSlash && TRAILING_SLASH_ENDPOINTS.has(joinedPath)) {
      targetUrl += '/';
    }

    // Preserve query parameters
    const searchParams = request.nextUrl.searchParams.toString();
    const fullUrl = searchParams ? `${targetUrl}?${searchParams}` : targetUrl;

    // Build headers — forward auth headers and content type
    const headers: Record<string, string> = {};

    const authHeader = request.headers.get('authorization');
    if (authHeader) headers['Authorization'] = authHeader;

    const apiKeyHeader = request.headers.get('x-api-key');
    if (apiKeyHeader) headers['X-API-Key'] = apiKeyHeader;

    const contentType = request.headers.get('content-type');
    if (contentType) headers['Content-Type'] = contentType;

    const acceptHeader = request.headers.get('accept');
    if (acceptHeader) headers['Accept'] = acceptHeader;

    const fetchOptions: RequestInit = {
      method,
      headers,
      redirect: 'follow',
      cache: 'no-store',              // ← Cache TTL: fully disabled at fetch level
    };

    if (method === 'POST' || method === 'PUT' || method === 'PATCH') {
      const body = await request.arrayBuffer();
      if (body.byteLength > 0 && body.byteLength <= MAX_BODY_SIZE) {
        fetchOptions.body = body;
      }
    }

    const backendResponse = await fetch(fullUrl, fetchOptions);

    const contentTypeResponse = backendResponse.headers.get('content-type');

    // ─── SSE streaming: if the backend returns text/event-stream, stream it ──
    if (contentTypeResponse?.includes('text/event-stream')) {
      const stream = new ReadableStream({
        async start(controller) {
          const reader = backendResponse.body?.getReader();
          if (!reader) {
            controller.close();
            return;
          }
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              controller.enqueue(value);
            }
          } catch (e) {
            controller.error(e);
          }
          controller.close();
        },
      });

      return new Response(stream, {
        status: backendResponse.status,
        statusText: backendResponse.statusText,
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });
    }

    // ─── Normal (non-SSE) response: buffer and return ──────────────────────
    const responseHeaders = new Headers();
    if (contentTypeResponse) {
      responseHeaders.set('Content-Type', contentTypeResponse);
    }

    responseHeaders.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    responseHeaders.set('Pragma', 'no-cache');
    responseHeaders.set('Expires', '0');

    const responseBody = await backendResponse.arrayBuffer();

    return new NextResponse(responseBody, {
      status: backendResponse.status,
      statusText: backendResponse.statusText,
      headers: responseHeaders,
    });

  } catch (error: unknown) {
    console.error('[API Proxy] Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown proxy error';

    if (message.includes('ECONNREFUSED') || message.includes('fetch failed')) {
      return NextResponse.json(
        {
          status: 'error',
          detail: `Cannot connect to Samba AD API backend at ${BACKEND_URL}. Ensure the backend is running on port 8099.`,
          error_code: 'BACKEND_UNREACHABLE',
        },
        { status: 502 }
      );
    }

    return NextResponse.json(
      { status: 'error', detail: `API proxy error: ${message}`, error_code: 'PROXY_ERROR' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  return proxyRequest(request, 'GET');
}

export async function POST(request: NextRequest) {
  return proxyRequest(request, 'POST');
}

export async function PUT(request: NextRequest) {
  return proxyRequest(request, 'PUT');
}

export async function PATCH(request: NextRequest) {
  return proxyRequest(request, 'PATCH');
}

export async function DELETE(request: NextRequest) {
  return proxyRequest(request, 'DELETE');
}
